# OAuthServer
Servidor Recursos y Autorizaciones con Oauth2

Una explicación de como funciona este programa en http://www.profesor-p.com/2018/10/19/securing-rest-services-with-oauth2-in-springboot/

